import {
  require_react
} from "./chunk-Q34MU4L5.js";
export default require_react();
//# sourceMappingURL=react.js.map
